# ChronicleX · SiYuan Calendar & Task Plugin

English | [简体中文](./README_zh_CN.md)

A **calendar-centered planner** for SiYuan: right-click any day to log a task, track its status, and **link it to a SiYuan document** for detailed notes.

> v1 focuses on "day-level + document-anchored" workflows — not time-slot scheduling, not a heavy calendar app.

---

## ✨ Features

- **Dual entry points**: Dock sidebar (always-on today list) + Full-screen Tab month view
- **4-state status**: todo / doing / done / cancelled — left-click icon to toggle complete, right-click for full state menu
- **3 priority levels**: high / normal / low — colored dots in month cells
- **Multi-tag**: free-form tags, auto-aggregated into filterable chips
- **SiYuan document linking** (the headline feature):
  - One-click create doc: pick a default notebook on first use, auto-used thereafter
  - New docs auto-prefilled with an event meta block (date / status / priority / tags / ID)
  - Or manually bind an existing doc via full-text search
  - Click 📄 to jump to the linked doc (toast on missing/deleted)
- **Day detail popover**: left-click any day in Tab → see all events → click to edit / click `+` to create
- **Search & filter**: keyword fuzzy match + status/tag chips in toolbar
- **Overdue highlight**: collapsible "⚠ N overdue" banner at Dock top
- **Persistence**: SiYuan Plugin Data API + 500ms debounce, survives restarts

Full changelog and technical details: [CHANGELOG.md](./CHANGELOG.md).

---

## 📥 Installation

### Option 1: from Release (recommended)

1. Download the latest `package.zip` from [Releases](https://gitee.com/wj741208617/plugin-ChronicleX-vite-svelte/releases)
2. Unzip into `{SiYuan workspace}/data/plugins/plugin-ChronicleX-vite-svelte/`
3. Restart SiYuan, enable via Settings → Marketplace → Downloaded

### Option 2: build from source

```bash
git clone https://gitee.com/wj741208617/plugin-ChronicleX-vite-svelte.git
cd plugin-ChronicleX-vite-svelte
pnpm i
pnpm run build
# outputs package.zip + dist/
```

---

## 🚀 Quick Start

Once enabled:

1. **The right-side Dock** shows 📅 ChronicleX with a mini calendar + today list
2. **Create an event**:
   - Click the `+` button at the top of the Dock for a quick today entry
   - Right-click any day (in Dock mini calendar or Tab month view) → menu with create options
   - Left-click any day in Tab month view → day detail popover → use the `+` inside
3. **Open full month view**: click 📅 in the top bar / press `⇧⌘L` / `Shift+Ctrl+L`
4. **Link a document**: at the bottom of the event editor, click `+ Create doc` (picks notebook first time) or `⊕ Bind existing doc` (search picker)
5. **Toggle status**: left-click `○` in Dock list → `●` (mark done); right-click `○` → 4-state menu
6. **Filter**: toggle chips in the Tab toolbar; fuzzy search by title/note

---

## ⚙️ Settings

Find at Settings → Marketplace → Downloaded → ChronicleX → gear:

| Setting | Default | Description |
|---|---|---|
| Default notebook | (unset) | Where "create doc" stores generated docs |
| Default doc path | `/ChronicleX` | Relative path inside the notebook |
| Week starts on | Monday | First column of the calendar |

---

## 🛠️ Development

```bash
pnpm i
pnpm run make-link   # On Windows you may need make-link-win (admin or dev mode)
pnpm run dev         # watch-build to dev/, LiveReload on port 35730
pnpm test            # run 45 unit tests
```

For development guide, SiYuan API boundaries, and compliance rules, see [CLAUDE.md](./CLAUDE.md) and [docs/superpowers/](./docs/superpowers/).

---

## 🗺️ Roadmap

v1 features listed above. Explicitly deferred to v2:

- Recurring events (weekly / monthly)
- Custom event colors
- Drag to reschedule
- Multi-day events
- Reminders / notifications
- Week view / day view
- Mobile deep optimization
- Import / export

Full deferred list in [CHANGELOG.md](./CHANGELOG.md#known-limitations).

---

## 📋 Compatibility

- Minimum SiYuan version: **3.2.1**
- Primary tested: Windows / macOS / Linux desktop
- Mobile: loads but not deeply optimized

---

## ⚖️ License

[MIT](./LICENSE) © Aether

Built on top of the [siyuan-note/plugin-sample-vite-svelte](https://github.com/siyuan-note/plugin-sample-vite-svelte) template.
