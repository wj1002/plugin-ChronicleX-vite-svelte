# ChronicleX · 思源笔记日历事项插件

[English](./README.md) | 简体中文

一个以**月历**为核心的「计划 + 回顾」插件,可以右键日子记录待办,完成后留痕,并能**一键关联思源文档**作为详情。

> v1 设计聚焦于「日级 + 文档化」,不做时间冲突排程,也不做重型日历。

---

## ✨ 主要功能

- **双入口**:Dock 侧栏(常驻今日清单)+ Tab 全屏月视图
- **4 态状态**:待办 / 进行中 / 已完成 / 已取消 — 左键 icon 一键切完成,右键弹全状态菜单
- **3 级优先级**:高 / 中 / 低,月格小点以颜色区分
- **多标签**:自由打,自动聚合可筛选
- **思源文档关联**(核心特色):
  - 一键建文档:首次选默认笔记本,之后自动用配置
  - 新文档自动预填事项元信息卡(日期 / 状态 / 优先级 / 标签 / ID)
  - 也可手动绑定已有文档(全文搜索)
  - 点 📄 图标跳到关联文档(失效时 toast 提示)
- **当日详情浮窗**:左键 Tab 月视图任意日子 → 看清单 → 点事项编辑 / 点 `+` 新建
- **搜索与筛选**:工具栏关键字模糊匹配 + 状态/标签 chips
- **过期高亮**:Dock 顶部「⚠ N 件过期」折叠横幅
- **持久化**:思源 Plugin Data API + 500ms 防抖,关闭思源不丢

完整版本变更与技术细节见 [CHANGELOG.md](./CHANGELOG.md)。

---

## 📥 安装

### 方式 1:从 Release 下载(推荐)

1. 到 [Releases](https://gitee.com/wj741208617/plugin-ChronicleX-vite-svelte/releases) 下载最新 `package.zip`
2. 解压到 `{思源工作空间}/data/plugins/plugin-ChronicleX-vite-svelte/`
3. 重启思源,在「设置 → 集市 → 已下载」中启用

### 方式 2:从源码构建

```bash
git clone https://gitee.com/wj741208617/plugin-ChronicleX-vite-svelte.git
cd plugin-ChronicleX-vite-svelte
pnpm i
pnpm run build
# 输出 package.zip + dist/ 目录
```

---

## 🚀 快速上手

启用后:

1. **右侧 Dock** 出现 📅 ChronicleX,打开它看到迷你月历 + 今日清单
2. **新建事项**:
   - Dock 顶部 `+` 按钮 → 今日快建
   - Dock 迷你日历 / Tab 月视图,**右键任意日子** → 菜单建事项
   - Tab 月视图**左键日子** → 当日详情浮窗 → 浮窗内 `+`
3. **打开全屏视图**:点顶栏 📅 / 按 `⇧⌘L` / `Shift+Ctrl+L`
4. **关联文档**:在事项编辑器底部,点 `+ 一键建文档`(首次选笔记本)或 `⊕ 绑定已有文档`(搜索器)
5. **状态切换**:Dock 列表左键 `○` → `●`(标完成);右键 `○` → 4 态菜单
6. **筛选**:Tab 工具栏 chip 切换,搜索框模糊匹配标题/备注

---

## ⚙️ 设置项

「设置 → 集市 → 已下载 → ChronicleX → 齿轮」:

| 设置 | 默认 | 说明 |
|---|---|---|
| 默认笔记本 | (未选择) | 「一键建文档」生成的文档存放笔记本 |
| 默认文档路径 | `/ChronicleX` | 笔记本下的相对路径 |
| 一周从哪天开始 | 周一 | 月历的第一列 |

---

## 🛠️ 开发

```bash
pnpm i
pnpm run make-link   # Windows 下可能需要 make-link-win(管理员或开发者模式)
pnpm run dev         # watch 编译到 dev/,LiveReload 在 35730 端口
pnpm test            # 跑 45 个单元测试
```

更多开发指南、思源 API 边界、合规要求见 [CLAUDE.md](./CLAUDE.md) 和 [docs/superpowers/](./docs/superpowers/)。

---

## 🗺️ 路线图

v1 已实现的功能见上方「主要功能」。明确推迟到 v2 的:

- 重复事项(每周 / 每月)
- 事项颜色自定义
- 拖拽改日期
- 跨日事件
- 提醒 / 通知
- 周视图 / 日视图
- 移动端深度优化
- 导入 / 导出

完整推迟清单见 [CHANGELOG.md](./CHANGELOG.md#known-limitations)。

---

## 📋 兼容性

- 最低思源版本:**3.2.1**
- 主测平台:Windows / macOS / Linux 桌面端
- 移动端:能加载,未深度优化

---

## ⚖️ 许可

[MIT](./LICENSE) © Aether

本项目基于 [siyuan-note/plugin-sample-vite-svelte](https://github.com/siyuan-note/plugin-sample-vite-svelte) 模板搭建。
